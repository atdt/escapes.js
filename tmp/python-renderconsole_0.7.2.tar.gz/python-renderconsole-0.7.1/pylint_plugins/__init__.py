"""
Local PyLint plugins.

$Id: __init__.py 14 2008-11-20 13:47:34Z alexios $
"""

__all__ = ['bedroomlan',
           ]

# End of file.
